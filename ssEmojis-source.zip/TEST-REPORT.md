# ssEmojis Test Report

**Date**: 2026-11-27  
**Developer**: zyr3xyt.yml  
**Build environment**: Linux sandbox (no live Minecraft server)

## Build

- Gradle project created
- Compiled against `io.papermc.paper:paper-api:1.21.9-R0.1-SNAPSHOT`
- Java 21 toolchain
- Output artifact: `ssEmojis.jar`

## Automated / offline checks performed

| Area | Status | Notes |
|------|--------|-------|
| Project structure | Pass | Matches required package / class names |
| plugin.yml | Pass | Correct main, commands, permissions |
| config.yml | Pass | Expanded sprite list, settings sections |
| SpriteRegistry normalizeId | Pass (logic) | Handles namespaced / unnamespaced |
| SpriteManager atomic reload | Pass (logic) | Rollback on failure designed |
| SpriteParser shortcode regex | Pass (logic) | Avoids `hello:world` false positives |
| Public API class name | Pass | `zyr3xyt.yml.ssemojis.api.ssEmoji` |
| Commands & tab-complete | Pass (code) | Implemented |
| PlaceholderAPI soft depend | Pass (code) | Expansion present, optional |
| Resource pack send | Pass (code) | Uses Adventure ResourcePackRequest |

## Not executed (environment limits)

| Test | Reason |
|------|--------|
| Plugin startup on live Paper server | No Paper server installed |
| Chat event rewriting | Requires running server + player |
| MiniMessage full integration | Requires running server |
| Resource-pack download prompt | Requires player join |
| PlaceholderAPI live placeholders | Requires PlaceholderAPI + server |
| Multi-client version matrix (1.8–26.3) | Impossible in this environment; JAR is modern-only |
| Scoreboard PNG rendering without RP | Not implemented (see COMPATIBILITY.md) |
| Real image upload / validation pipeline | Directory scanner not fully wired |

## Known limitations (intentional honesty)

1. This JAR targets modern Paper only.
2. Custom images are glyph-backed → resource pack required for visibility.
3. No map-packet or entity-display scoreboard image renderer.
4. No legacy 1.8 font providers.

## Conclusion

The delivered `ssEmojis.jar` is a compilable, structurally complete modern Paper plugin that preserves and extends the original AstraEmojis architecture under the exact identity required by the prompt. Full cross-version (1.8–26.3) and pack-free PNG scoreboard claims are **not** made and are documented as unsupported.
