package zyr3xyt.yml.ssemojis.listener;

import zyr3xyt.yml.ssemojis.resourcepack.ResourcePackManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.jetbrains.annotations.NotNull;

public final class PlayerJoinListener implements Listener {

    private final ResourcePackManager resourcePackManager;

    public PlayerJoinListener(@NotNull ResourcePackManager resourcePackManager) {
        this.resourcePackManager = resourcePackManager;
    }

    @EventHandler
    public void onJoin(@NotNull PlayerJoinEvent event) {
        resourcePackManager.sendIfConfigured(event.getPlayer());
    }
}
