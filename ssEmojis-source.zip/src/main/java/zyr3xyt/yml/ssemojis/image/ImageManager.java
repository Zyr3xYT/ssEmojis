package zyr3xyt.yml.ssemojis.image;

import zyr3xyt.yml.ssemojis.sprite.Sprite;
import zyr3xyt.yml.ssemojis.sprite.SpriteManager;
import zyr3xyt.yml.ssemojis.sprite.SpriteRegistry;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Discovers PNG files under plugins/ssEmojis/images/ and registers them
 * as glyph-backed custom sprites. Assigns sequential Private Use Area glyphs.
 */
public final class ImageManager {

    public record CustomImage(
        @NotNull String id,
        @NotNull Path file,
        @NotNull String glyph,
        int width,
        int height
    ) {}

    private final Path dataFolder;
    private final SpriteManager spriteManager;
    private final Logger logger;
    private final Map<String, CustomImage> images = new ConcurrentHashMap<>();

    private int maxWidth = 128;
    private int maxHeight = 128;
    private int maxFileSizeKb = 256;
    private int glyphStart = 0xE100;
    private boolean enabled = true;
    private String directoryName = "images";

    public ImageManager(@NotNull Path dataFolder, @NotNull SpriteManager spriteManager, @NotNull Logger logger) {
        this.dataFolder = dataFolder;
        this.spriteManager = spriteManager;
        this.logger = logger;
    }

    public void configure(boolean enabled, String directory, int maxWidth, int maxHeight, int maxFileSizeKb, int glyphStart) {
        this.enabled = enabled;
        this.directoryName = directory == null || directory.isBlank() ? "images" : directory;
        this.maxWidth = Math.max(8, maxWidth);
        this.maxHeight = Math.max(8, maxHeight);
        this.maxFileSizeKb = Math.max(16, maxFileSizeKb);
        this.glyphStart = glyphStart > 0 ? glyphStart : 0xE100;
    }

    @NotNull
    public Path imagesDirectory() {
        return dataFolder.resolve(directoryName);
    }

    /**
     * Scan images folder, validate PNGs, assign glyphs, register as custom sprites.
     * Returns the list of successfully loaded custom images.
     */
    @NotNull
    public List<CustomImage> reload() {
        images.clear();
        if (!enabled) {
            return List.of();
        }

        Path dir = imagesDirectory();
        try {
            Files.createDirectories(dir);
        } catch (IOException e) {
            logger.warning("Could not create images directory: " + e.getMessage());
            return List.of();
        }

        List<CustomImage> loaded = new ArrayList<>();
        int glyphIndex = 0;

        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, "*.{png,PNG}")) {
            for (Path file : stream) {
                if (!Files.isRegularFile(file)) continue;
                try {
                    CustomImage img = loadOne(file, glyphIndex);
                    if (img != null) {
                        loaded.add(img);
                        images.put(img.id(), img);
                        // Register into sprite manager (overwrite if exists)
                        try {
                            if (spriteManager.hasSprite(img.id())) {
                                spriteManager.unregisterSprite(img.id());
                            }
                            spriteManager.registerSprite(img.id(), Sprite.ofCustomImage(img.id(), img.glyph()));
                        } catch (Exception regEx) {
                            logger.warning("Could not register image sprite " + img.id() + ": " + regEx.getMessage());
                        }
                        glyphIndex++;
                    }
                } catch (Exception e) {
                    logger.warning("Skipping image " + file.getFileName() + ": " + e.getMessage());
                }
            }
        } catch (IOException e) {
            logger.warning("Failed to scan images directory: " + e.getMessage());
        }

        // Also scan one level of subfolders (custom/)
        Path customDir = dir.resolve("custom");
        if (Files.isDirectory(customDir)) {
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(customDir, "*.{png,PNG}")) {
                for (Path file : stream) {
                    if (!Files.isRegularFile(file)) continue;
                    try {
                        String baseName = stripExtension(file.getFileName().toString());
                        String id = "custom:" + baseName.toLowerCase(Locale.ROOT);
                        CustomImage img = loadOneWithId(file, id, glyphIndex);
                        if (img != null) {
                            loaded.add(img);
                            images.put(img.id(), img);
                            try {
                                if (spriteManager.hasSprite(img.id())) {
                                    spriteManager.unregisterSprite(img.id());
                                }
                                spriteManager.registerSprite(img.id(), Sprite.ofCustomImage(img.id(), img.glyph()));
                            } catch (Exception regEx) {
                                logger.warning("Could not register image sprite " + img.id() + ": " + regEx.getMessage());
                            }
                            glyphIndex++;
                        }
                    } catch (Exception e) {
                        logger.warning("Skipping image " + file.getFileName() + ": " + e.getMessage());
                    }
                }
            } catch (IOException e) {
                logger.warning("Failed to scan custom/ images: " + e.getMessage());
            }
        }

        logger.info("Loaded " + loaded.size() + " custom image(s) from " + dir);
        return loaded;
    }

    @Nullable
    private CustomImage loadOne(@NotNull Path file, int glyphIndex) throws IOException {
        String baseName = stripExtension(file.getFileName().toString());
        String id = SpriteRegistry.normalizeId(baseName, "custom");
        if (id == null) {
            id = "custom:" + baseName.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_./-]", "_");
        }
        return loadOneWithId(file, id, glyphIndex);
    }

    @Nullable
    private CustomImage loadOneWithId(@NotNull Path file, @NotNull String id, int glyphIndex) throws IOException {
        long size = Files.size(file);
        if (size > maxFileSizeKb * 1024L) {
            logger.warning("Image too large (" + size + " bytes): " + file.getFileName());
            return null;
        }

        BufferedImage image = ImageIO.read(file.toFile());
        if (image == null) {
            logger.warning("Not a valid image: " + file.getFileName());
            return null;
        }
        if (image.getWidth() > maxWidth || image.getHeight() > maxHeight) {
            logger.warning("Image dimensions exceed limit (" + image.getWidth() + "x" + image.getHeight() + "): " + file.getFileName());
            return null;
        }

        int codePoint = glyphStart + glyphIndex;
        if (codePoint > 0xF8FF) {
            logger.warning("Out of Private Use Area glyphs; skipping " + file.getFileName());
            return null;
        }
        String glyph = new String(Character.toChars(codePoint));
        return new CustomImage(id, file, glyph, image.getWidth(), image.getHeight());
    }

    private static String stripExtension(String name) {
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    @NotNull
    public Map<String, CustomImage> getImages() {
        return Collections.unmodifiableMap(images);
    }

    @Nullable
    public CustomImage getImage(@Nullable String id) {
        if (id == null) return null;
        CustomImage img = images.get(id);
        if (img != null) return img;
        // try normalized
        String norm = SpriteRegistry.normalizeId(id, "custom");
        return norm == null ? null : images.get(norm);
    }

    public boolean hasImage(@Nullable String id) {
        return getImage(id) != null;
    }
}
