package zyr3xyt.yml.ssemojis.sprite;

import zyr3xyt.yml.ssemojis.config.ConfigManager;
import zyr3xyt.yml.ssemojis.resourcepack.ResourcePackSettings;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;

/**
 * Central registry manager. Holds an atomic immutable snapshot.
 * Thread-safe lookups and safe reload with rollback on failure.
 */
public final class SpriteManager {

    private final ConfigManager configManager;
    private final Logger logger;
    private final AtomicReference<SpriteRegistry> registry = new AtomicReference<>(SpriteRegistry.empty());

    public SpriteManager(@NotNull ConfigManager configManager, @NotNull Logger logger) {
        this.configManager = configManager;
        this.logger = logger;
    }

    public void reload() {
        SpriteRegistry previous = registry.get();
        try {
            SpriteRegistry next = configManager.loadRegistry();
            registry.set(next);
            logger.info("Loaded " + next.sprites().size() + " sprites (default namespace: " + next.defaultNamespace() + ")");
        } catch (Exception e) {
            logger.severe("Reload failed, retaining previous registry: " + e.getMessage());
            registry.set(previous);
            throw new RuntimeException("ssEmojis reload failed: " + e.getMessage(), e);
        }
    }

    @NotNull
    public SpriteRegistry registry() {
        return registry.get();
    }

    @Nullable
    public Sprite getSprite(@Nullable String id) {
        return registry.get().get(id);
    }

    public boolean hasSprite(@Nullable String id) {
        return registry.get().has(id);
    }

    public void registerSprite(@NotNull String id, @NotNull Sprite sprite) {
        String normalized = SpriteRegistry.normalizeId(id, registry.get().defaultNamespace());
        if (normalized == null) {
            throw new IllegalArgumentException("Invalid sprite id: " + id);
        }
        registry.updateAndGet(current -> {
            Map<String, Sprite> map = new LinkedHashMap<>(current.asMap());
            if (map.containsKey(normalized)) {
                throw new IllegalStateException("Sprite already registered: " + normalized);
            }
            map.put(normalized, new Sprite(normalized, sprite.atlas(), sprite.spriteName(), sprite.glyph(), sprite.isCustomImage()));
            return current.withSprites(map);
        });
    }

    public void registerSprite(@NotNull String id, @NotNull String glyph) {
        registerSprite(id, Sprite.ofGlyph(id, glyph));
    }

    public boolean unregisterSprite(@Nullable String id) {
        String normalized = SpriteRegistry.normalizeId(id, registry.get().defaultNamespace());
        if (normalized == null) {
            return false;
        }
        AtomicReference<Boolean> removed = new AtomicReference<>(false);
        registry.updateAndGet(current -> {
            Map<String, Sprite> map = new LinkedHashMap<>(current.asMap());
            if (map.remove(normalized) != null) {
                removed.set(true);
            }
            return current.withSprites(map);
        });
        return removed.get();
    }

    @NotNull
    public Collection<Sprite> getSprites() {
        return registry.get().sprites();
    }

    @NotNull
    public ResourcePackSettings resourcePackSettings() {
        return registry.get().resourcePackSettings();
    }
}
