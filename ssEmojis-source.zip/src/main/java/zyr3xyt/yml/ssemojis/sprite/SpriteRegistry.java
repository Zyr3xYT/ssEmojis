package zyr3xyt.yml.ssemojis.sprite;

import zyr3xyt.yml.ssemojis.resourcepack.ResourcePackSettings;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Immutable snapshot of the sprite registry.
 * Replaced atomically on reload for thread-safety.
 */
public final class SpriteRegistry {

    private static final Pattern ID = Pattern.compile("^[a-z0-9_.-]+:[a-z0-9_./-]+$");

    private final String defaultNamespace;
    private final String unknownBehavior;
    private final boolean colonParserEnabled;
    private final boolean minimessageTagsEnabled;
    private final boolean debug;
    private final Map<String, Sprite> sprites;
    private final ResourcePackSettings resourcePackSettings;

    public SpriteRegistry(
        String defaultNamespace,
        String unknownBehavior,
        boolean colonParserEnabled,
        boolean minimessageTagsEnabled,
        boolean debug,
        Map<String, Sprite> sprites,
        ResourcePackSettings resourcePackSettings
    ) {
        this.defaultNamespace = defaultNamespace;
        this.unknownBehavior = unknownBehavior;
        this.colonParserEnabled = colonParserEnabled;
        this.minimessageTagsEnabled = minimessageTagsEnabled;
        this.debug = debug;
        this.sprites = Collections.unmodifiableMap(new LinkedHashMap<>(sprites));
        this.resourcePackSettings = resourcePackSettings;
    }

    public static SpriteRegistry empty() {
        return new SpriteRegistry("minecraft", "keep", true, true, false, Map.of(), ResourcePackSettings.disabled());
    }

    @Nullable
    public static String normalizeId(@Nullable String id, @NotNull String defaultNamespace) {
        if (id == null || defaultNamespace == null) {
            return null;
        }
        String normalized = id.trim().toLowerCase(Locale.ROOT);
        if (normalized.isEmpty()) {
            return null;
        }
        if (!normalized.contains(":")) {
            normalized = defaultNamespace.toLowerCase(Locale.ROOT) + ":" + normalized;
        }
        return ID.matcher(normalized).matches() ? normalized : null;
    }

    @NotNull
    public String defaultNamespace() {
        return defaultNamespace;
    }

    @NotNull
    public String unknownBehavior() {
        return unknownBehavior;
    }

    public boolean colonParserEnabled() {
        return colonParserEnabled;
    }

    public boolean minimessageTagsEnabled() {
        return minimessageTagsEnabled;
    }

    public boolean debug() {
        return debug;
    }

    @NotNull
    public ResourcePackSettings resourcePackSettings() {
        return resourcePackSettings;
    }

    @Nullable
    public Sprite get(@Nullable String id) {
        String normalized = normalizeId(id, defaultNamespace);
        return normalized == null ? null : sprites.get(normalized);
    }

    public boolean has(@Nullable String id) {
        return get(id) != null;
    }

    @NotNull
    public Map<String, Sprite> asMap() {
        return sprites;
    }

    @NotNull
    public Collection<Sprite> sprites() {
        return sprites.values();
    }

    @NotNull
    public SpriteRegistry withSprites(@NotNull Map<String, Sprite> updatedSprites) {
        return new SpriteRegistry(defaultNamespace, unknownBehavior, colonParserEnabled, minimessageTagsEnabled,
            debug, updatedSprites, resourcePackSettings);
    }
}
