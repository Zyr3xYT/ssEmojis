package zyr3xyt.yml.ssemojis.resourcepack;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;

/**
 * Lightweight embedded HTTP server that serves the generated resource pack ZIP.
 * Binds to the configured port so players can download it without an external host.
 */
public final class PackHttpServer implements AutoCloseable {

    private final Logger logger;
    private final AtomicReference<byte[]> packBytes = new AtomicReference<>(new byte[0]);
    private final AtomicReference<String> sha1 = new AtomicReference<>("");
    private @Nullable HttpServer server;
    private int port;
    private String bindAddress = "0.0.0.0";

    public PackHttpServer(@NotNull Logger logger) {
        this.logger = logger;
    }

    public synchronized void start(int port, @NotNull String bind) throws IOException {
        stop();
        this.port = port;
        this.bindAddress = bind == null || bind.isBlank() ? "0.0.0.0" : bind;

        server = HttpServer.create(new InetSocketAddress(this.bindAddress, this.port), 0);
        server.createContext("/ssemojis-pack.zip", new PackHandler());
        server.createContext("/", exchange -> {
            String body = "ssEmojis resource pack server. Get the pack at /ssemojis-pack.zip";
            byte[] bytes = body.getBytes();
            exchange.getResponseHeaders().add("Content-Type", "text/plain");
            exchange.sendResponseHeaders(200, bytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(bytes);
            }
        });
        server.setExecutor(Executors.newFixedThreadPool(2));
        server.start();
        logger.info("ssEmojis pack HTTP server listening on " + this.bindAddress + ":" + this.port);
    }

    public synchronized void stop() {
        if (server != null) {
            server.stop(0);
            server = null;
            logger.info("ssEmojis pack HTTP server stopped.");
        }
    }

    public void updatePack(@NotNull byte[] zipBytes, @NotNull String sha1Hex) {
        packBytes.set(zipBytes);
        sha1.set(sha1Hex);
    }

    public int getPort() {
        return port;
    }

    @NotNull
    public String getSha1() {
        return sha1.get();
    }

    public boolean isRunning() {
        return server != null;
    }

    /**
     * Builds the download URL players will use.
     * Uses the public host if provided, otherwise the bind address (may be 0.0.0.0).
     */
    @NotNull
    public String buildUrl(@Nullable String publicHost) {
        String host = (publicHost == null || publicHost.isBlank()) ? "127.0.0.1" : publicHost;
        // Prefer the server's public IP when possible; admin can override via config later
        return "http://" + host + ":" + port + "/ssemojis-pack.zip";
    }

    @Override
    public void close() {
        stop();
    }

    private final class PackHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"GET".equalsIgnoreCase(exchange.getRequestMethod()) && !"HEAD".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }
            byte[] data = packBytes.get();
            exchange.getResponseHeaders().add("Content-Type", "application/zip");
            exchange.getResponseHeaders().add("Content-Disposition", "attachment; filename=\"ssemojis-pack.zip\"");
            exchange.getResponseHeaders().add("Cache-Control", "no-cache");
            if ("HEAD".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(200, data.length);
                exchange.close();
                return;
            }
            exchange.sendResponseHeaders(200, data.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(data);
            }
        }
    }
}
