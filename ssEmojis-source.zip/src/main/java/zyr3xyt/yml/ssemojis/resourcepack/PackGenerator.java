package zyr3xyt.yml.ssemojis.resourcepack;

import zyr3xyt.yml.ssemojis.image.ImageManager;
import org.jetbrains.annotations.NotNull;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Generates a Minecraft resource pack ZIP from custom images.
 * Creates bitmap font providers so Private Use Area glyphs render as the PNGs.
 */
public final class PackGenerator {

    public record GeneratedPack(
        @NotNull byte[] zipBytes,
        @NotNull String sha1Hex,
        @NotNull Path cacheFile,
        int imageCount
    ) {}

    private final Path cacheDir;
    private final Logger logger;

    public PackGenerator(@NotNull Path dataFolder, @NotNull Logger logger) {
        this.cacheDir = dataFolder.resolve("cache");
        this.logger = logger;
    }

    @NotNull
    public GeneratedPack generate(@NotNull Map<String, ImageManager.CustomImage> images) throws IOException {
        Files.createDirectories(cacheDir);

        if (images.isEmpty()) {
            // Minimal empty pack so the HTTP endpoint always has something
            byte[] empty = buildEmptyPack();
            Path out = cacheDir.resolve("ssemojis-pack.zip");
            Files.write(out, empty);
            return new GeneratedPack(empty, sha1(empty), out, 0);
        }

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(baos)) {
            // pack.mcmeta
            String mcmeta = """
                {
                  "pack": {
                    "pack_format": 34,
                    "description": "ssEmojis auto-generated sprite pack"
                  }
                }
                """;
            put(zos, "pack.mcmeta", mcmeta.getBytes(StandardCharsets.UTF_8));

            // Build font providers
            StringBuilder providers = new StringBuilder();
            providers.append("{\n  \"providers\": [\n");

            int i = 0;
            for (ImageManager.CustomImage img : images.values()) {
                String texturePath = "ssemojis:font/" + sanitize(img.id());
                // Copy PNG into pack
                byte[] pngBytes = Files.readAllBytes(img.file());
                put(zos, "assets/ssemojis/textures/font/" + sanitize(img.id()) + ".png", pngBytes);

                if (i > 0) providers.append(",\n");
                providers.append("    {\n");
                providers.append("      \"type\": \"bitmap\",\n");
                providers.append("      \"file\": \"").append(texturePath).append("\",\n");
                // ascent roughly half height for decent baseline
                int ascent = Math.max(1, img.height() * 7 / 8);
                providers.append("      \"ascent\": ").append(ascent).append(",\n");
                providers.append("      \"height\": ").append(img.height()).append(",\n");
                // Unicode escape for the glyph
                int cp = img.glyph().codePointAt(0);
                providers.append("      \"chars\": [\"\\u").append(String.format("%04X", cp)).append("\"]\n");
                providers.append("    }");
                i++;
            }
            providers.append("\n  ]\n}\n");

            // Put providers into minecraft default font so chat glyphs work
            put(zos, "assets/minecraft/font/default.json", providers.toString().getBytes(StandardCharsets.UTF_8));
        }

        byte[] zipBytes = baos.toByteArray();
        Path out = cacheDir.resolve("ssemojis-pack.zip");
        Files.write(out, zipBytes);
        String hash = sha1(zipBytes);
        logger.info("Generated resource pack with " + images.size() + " image(s), SHA-1: " + hash);
        return new GeneratedPack(zipBytes, hash, out, images.size());
    }

    private static byte[] buildEmptyPack() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(baos)) {
            String mcmeta = """
                {
                  "pack": {
                    "pack_format": 34,
                    "description": "ssEmojis (no custom images)"
                  }
                }
                """;
            put(zos, "pack.mcmeta", mcmeta.getBytes(StandardCharsets.UTF_8));
        }
        return baos.toByteArray();
    }

    private static void put(ZipOutputStream zos, String name, byte[] data) throws IOException {
        ZipEntry entry = new ZipEntry(name);
        zos.putNextEntry(entry);
        zos.write(data);
        zos.closeEntry();
    }

    private static String sanitize(String id) {
        return id.toLowerCase().replace(':', '_').replaceAll("[^a-z0-9_./-]", "_");
    }

    @NotNull
    public static String sha1(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] dig = md.digest(data);
            return HexFormat.of().formatHex(dig);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-1 not available", e);
        }
    }
}
