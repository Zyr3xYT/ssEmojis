package zyr3xyt.yml.ssemojis.resourcepack;

import org.jetbrains.annotations.NotNull;

/**
 * Placeholder for future glyph / font generation utilities.
 * Currently glyph assignment is handled entirely via config.yml.
 */
public final class GlyphManager {

    private GlyphManager() {
    }

    public static boolean isValidPrivateUse(@NotNull String glyph) {
        if (glyph.isEmpty()) return false;
        int cp = glyph.codePointAt(0);
        // Basic Multilingual Plane Private Use Area
        return (cp >= 0xE000 && cp <= 0xF8FF);
    }
}
