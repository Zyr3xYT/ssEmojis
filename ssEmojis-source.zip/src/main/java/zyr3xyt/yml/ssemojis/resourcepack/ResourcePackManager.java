package zyr3xyt.yml.ssemojis.resourcepack;

import zyr3xyt.yml.ssemojis.image.ImageManager;
import zyr3xyt.yml.ssemojis.sprite.SpriteManager;
import net.kyori.adventure.resource.ResourcePackInfo;
import net.kyori.adventure.resource.ResourcePackRequest;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.net.URI;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * Manages resource pack delivery.
 * Prefers the auto-generated + self-hosted pack when enabled.
 * Falls back to a manually configured external URL.
 */
public final class ResourcePackManager {

    private final SpriteManager spriteManager;
    private final ImageManager imageManager;
    private final PackGenerator packGenerator;
    private final PackHttpServer httpServer;
    private final Logger logger;

    private boolean autoGenerate = true;
    private boolean autoHost = true;
    private int hostPort = 8765;
    private String hostBind = "0.0.0.0";
    private @Nullable String publicHost = null;
    private @Nullable PackGenerator.GeneratedPack lastPack = null;

    public ResourcePackManager(
        @NotNull SpriteManager spriteManager,
        @NotNull ImageManager imageManager,
        @NotNull PackGenerator packGenerator,
        @NotNull PackHttpServer httpServer,
        @NotNull Logger logger
    ) {
        this.spriteManager = spriteManager;
        this.imageManager = imageManager;
        this.packGenerator = packGenerator;
        this.httpServer = httpServer;
        this.logger = logger;
    }

    public void configure(boolean autoGenerate, boolean autoHost, int hostPort, String hostBind, @Nullable String publicHost) {
        this.autoGenerate = autoGenerate;
        this.autoHost = autoHost;
        this.hostPort = hostPort > 0 ? hostPort : 8765;
        this.hostBind = hostBind == null || hostBind.isBlank() ? "0.0.0.0" : hostBind;
        this.publicHost = publicHost;
    }

    /**
     * Rebuild the pack from current custom images and (re)start the HTTP server if needed.
     */
    public void rebuildAndHost() {
        if (!autoGenerate) {
            logger.info("Auto resource-pack generation is disabled.");
            return;
        }
        try {
            lastPack = packGenerator.generate(imageManager.getImages());
            httpServer.updatePack(lastPack.zipBytes(), lastPack.sha1Hex());

            if (autoHost) {
                if (!httpServer.isRunning()) {
                    httpServer.start(hostPort, hostBind);
                }
                httpServer.updatePack(lastPack.zipBytes(), lastPack.sha1Hex());
                logger.info("Auto resource pack ready (" + lastPack.imageCount() + " images). SHA-1: " + lastPack.sha1Hex());
            }
        } catch (Exception e) {
            logger.severe("Failed to generate/host resource pack: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void sendIfConfigured(@NotNull Player player) {
        ResourcePackSettings settings = spriteManager.resourcePackSettings();
        if (!settings.enabled()) {
            return;
        }

        String url;
        String sha1;

        if (autoGenerate && autoHost && lastPack != null && lastPack.imageCount() > 0 && httpServer.isRunning()) {
            String host = publicHost;
            if (host == null || host.isBlank()) {
                try {
                    String serverIp = Bukkit.getIp();
                    if (serverIp != null && !serverIp.isBlank() && !serverIp.equals("0.0.0.0")) {
                        host = serverIp;
                    } else if (player.getAddress() != null) {
                        host = player.getAddress().getAddress().getHostAddress();
                    } else {
                        host = "127.0.0.1";
                    }
                } catch (Exception e) {
                    host = "127.0.0.1";
                }
            }
            url = "http://" + host + ":" + httpServer.getPort() + "/ssemojis-pack.zip";
            sha1 = lastPack.sha1Hex();
        } else if (settings.url() != null && !settings.url().isBlank()) {
            url = settings.url();
            sha1 = settings.sha1();
        } else {
            return;
        }

        try {
            URI uri = URI.create(url);
            ResourcePackInfo info = ResourcePackInfo.resourcePackInfo()
                .uri(uri)
                .id(UUID.nameUUIDFromBytes(url.getBytes()))
                .build();

            ResourcePackRequest request = ResourcePackRequest.resourcePackRequest()
                .packs(info)
                .required(settings.force())
                .prompt(Component.text(settings.prompt() == null ? "ssEmojis resource pack" : settings.prompt()))
                .build();

            player.sendResourcePacks(request);
        } catch (Exception e) {
            logger.warning("Could not send resource pack to " + player.getName() + ": " + e.getMessage());
        }
    }

    public void shutdown() {
        httpServer.stop();
    }

    @Nullable
    public PackGenerator.GeneratedPack getLastPack() {
        return lastPack;
    }

    public boolean isAutoHosting() {
        return autoHost && httpServer.isRunning();
    }

    public int getHostPort() {
        return httpServer.getPort();
    }
}
