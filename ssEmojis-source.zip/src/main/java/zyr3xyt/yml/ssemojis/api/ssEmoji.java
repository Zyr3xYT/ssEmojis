package zyr3xyt.yml.ssemojis.api;

import zyr3xyt.yml.ssemojis.ssEmojis;
import zyr3xyt.yml.ssemojis.sprite.Sprite;
import zyr3xyt.yml.ssemojis.sprite.SpriteManager;
import zyr3xyt.yml.ssemojis.sprite.SpriteParser;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.Collection;
import java.util.Optional;

/**
 * Public API for ssEmojis.
 * <pre>
 * ssEmoji api = ssEmoji.getInstance();
 * Component msg = api.parse("Hello :diamond:");
 * api.registerSprite("custom:logo", "\uE200");
 * </pre>
 */
public final class ssEmoji {

    private static ssEmoji instance;

    private final SpriteManager spriteManager;
    private final SpriteParser spriteParser;

    public ssEmoji(@NotNull SpriteManager spriteManager, @NotNull SpriteParser spriteParser) {
        this.spriteManager = spriteManager;
        this.spriteParser = spriteParser;
        instance = this;
    }

    /**
     * Returns the live API instance, or null if the plugin is not enabled.
     */
    @Nullable
    public static ssEmoji getInstance() {
        if (instance != null) {
            return instance;
        }
        Plugin plugin = Bukkit.getPluginManager().getPlugin("ssEmojis");
        if (plugin instanceof ssEmojis ss) {
            return ss.getAPI();
        }
        return null;
    }

    @NotNull
    public static Optional<ssEmoji> get() {
        return Optional.ofNullable(getInstance());
    }

    @Nullable
    public Sprite getSprite(@Nullable String id) {
        return spriteManager.getSprite(id);
    }

    public boolean hasSprite(@Nullable String id) {
        return spriteManager.hasSprite(id);
    }

    @NotNull
    public Collection<Sprite> getSprites() {
        return spriteManager.getSprites();
    }

    /**
     * Parse shortcodes into an Adventure Component.
     */
    @NotNull
    public Component parse(@NotNull String input) {
        return spriteParser.parse(input);
    }

    public void registerSprite(@NotNull String id, @NotNull String glyph) {
        spriteManager.registerSprite(id, glyph);
    }

    public void registerSprite(@NotNull String id, @NotNull Sprite sprite) {
        spriteManager.registerSprite(id, sprite);
    }

    public boolean unregisterSprite(@Nullable String id) {
        return spriteManager.unregisterSprite(id);
    }

    // ---- Image API (glyph-backed; true pack-free PNG rendering is not implemented) ----

    public boolean hasImage(@Nullable String id) {
        Sprite s = spriteManager.getSprite(id);
        return s != null && s.isCustomImage();
    }

    @Nullable
    public Sprite getImage(@Nullable String id) {
        Sprite s = spriteManager.getSprite(id);
        return (s != null && s.isCustomImage()) ? s : null;
    }

    /**
     * Registers a custom image as a glyph-backed sprite.
     * The actual PNG must still be provided via a resource pack for clients to see it.
     * True resource-pack-free PNG rendering in chat/scoreboards is not supported by vanilla Minecraft.
     */
    public void registerImage(@NotNull String id, @NotNull File file) {
        // Placeholder: real implementation would validate the PNG, assign a glyph, and
        // optionally generate a resource-pack fragment. For now we register a glyph placeholder.
        if (!file.exists() || !file.getName().toLowerCase().endsWith(".png")) {
            throw new IllegalArgumentException("File must be an existing PNG: " + file);
        }
        // Assign a deterministic private-use glyph based on hash of id (demo only)
        int hash = Math.abs(id.hashCode() % 0x1000);
        String glyph = new String(Character.toChars(0xE200 + hash));
        spriteManager.registerSprite(id, Sprite.ofCustomImage(id, glyph));
    }

    public boolean unregisterImage(@Nullable String id) {
        Sprite s = spriteManager.getSprite(id);
        if (s != null && s.isCustomImage()) {
            return spriteManager.unregisterSprite(id);
        }
        return false;
    }

    public void reloadImages() {
        // Images are currently loaded from the same config.yml sprites section.
        // A dedicated images/ directory scanner can be added later.
        spriteManager.reload();
    }
}
