package zyr3xyt.yml.ssemojis.placeholder;

import zyr3xyt.yml.ssemojis.ssEmojis;
import zyr3xyt.yml.ssemojis.sprite.Sprite;
import zyr3xyt.yml.ssemojis.sprite.SpriteManager;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Optional PlaceholderAPI expansion.
 * %ssem_count%  %ssem_exists_<id>%  %ssem_glyph_<id>%
 */
public final class ssEmojisExpansion extends PlaceholderExpansion {

    private final ssEmojis plugin;
    private final SpriteManager spriteManager;

    public ssEmojisExpansion(@NotNull ssEmojis plugin, @NotNull SpriteManager spriteManager) {
        this.plugin = plugin;
        this.spriteManager = spriteManager;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "ssem";
    }

    @Override
    public @NotNull String getAuthor() {
        return "zyr3xyt.yml";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public @Nullable String onPlaceholderRequest(Player player, @NotNull String params) {
        if (params.equalsIgnoreCase("count")) {
            return String.valueOf(spriteManager.getSprites().size());
        }
        if (params.toLowerCase().startsWith("exists_")) {
            String id = params.substring(7);
            return String.valueOf(spriteManager.hasSprite(id));
        }
        if (params.toLowerCase().startsWith("glyph_")) {
            String id = params.substring(6);
            Sprite s = spriteManager.getSprite(id);
            if (s != null && s.glyph() != null) {
                return s.glyph();
            }
            return "";
        }
        return null;
    }
}
