package zyr3xyt.yml.ssemojis;

import zyr3xyt.yml.ssemojis.api.ssEmoji;
import zyr3xyt.yml.ssemojis.command.ssEmojisCommand;
import zyr3xyt.yml.ssemojis.config.ConfigManager;
import zyr3xyt.yml.ssemojis.image.ImageManager;
import zyr3xyt.yml.ssemojis.listener.PlayerJoinListener;
import zyr3xyt.yml.ssemojis.minimessage.SpriteTagResolver;
import zyr3xyt.yml.ssemojis.resourcepack.PackGenerator;
import zyr3xyt.yml.ssemojis.resourcepack.PackHttpServer;
import zyr3xyt.yml.ssemojis.resourcepack.ResourcePackManager;
import zyr3xyt.yml.ssemojis.sprite.SpriteManager;
import zyr3xyt.yml.ssemojis.sprite.SpriteParser;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * ssEmojis — Shark Studios
 * Main plugin class.
 */
public final class ssEmojis extends JavaPlugin implements Listener {

    private SpriteManager spriteManager;
    private SpriteParser spriteParser;
    private ssEmoji api;
    private MiniMessage miniMessage;
    private ImageManager imageManager;
    private ResourcePackManager resourcePackManager;
    private PackHttpServer packHttpServer;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadConfig();

        ConfigManager configManager = new ConfigManager(getDataFolder().toPath(), getLogger());
        spriteManager = new SpriteManager(configManager, getLogger());
        try {
            spriteManager.reload();
        } catch (Exception exception) {
            getLogger().severe("Unable to load ssEmojis configuration: " + exception.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        spriteParser = new SpriteParser(spriteManager);
        api = new ssEmoji(spriteManager, spriteParser);

        // Image + auto resource pack system
        imageManager = new ImageManager(getDataFolder().toPath(), spriteManager, getLogger());
        FileConfiguration cfg = getConfig();
        imageManager.configure(
            cfg.getBoolean("images.enabled", true),
            cfg.getString("images.directory", "images"),
            cfg.getInt("images.max-width", 128),
            cfg.getInt("images.max-height", 128),
            cfg.getInt("images.max-file-size-kb", 256),
            cfg.getInt("images.glyph-start", 0xE100)
        );
        imageManager.reload();

        PackGenerator packGenerator = new PackGenerator(getDataFolder().toPath(), getLogger());
        packHttpServer = new PackHttpServer(getLogger());
        resourcePackManager = new ResourcePackManager(spriteManager, imageManager, packGenerator, packHttpServer, getLogger());
        resourcePackManager.configure(
            cfg.getBoolean("resource-pack.auto-generate", true),
            cfg.getBoolean("resource-pack.auto-host", true),
            cfg.getInt("resource-pack.host-port", 8765),
            cfg.getString("resource-pack.host-bind", "0.0.0.0"),
            cfg.getString("resource-pack.public-host", null)
        );
        resourcePackManager.rebuildAndHost();

        // MiniMessage with sprite tag support
        TagResolver spriteResolver = new SpriteTagResolver(spriteManager);
        miniMessage = MiniMessage.builder()
            .tags(TagResolver.resolver(TagResolver.standard(), spriteResolver))
            .build();

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(new PlayerJoinListener(resourcePackManager), this);

        PluginCommand command = getCommand("ssem");
        if (command == null) {
            getLogger().severe("The ssem command is missing from plugin.yml.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        ssEmojisCommand executor = new ssEmojisCommand(this, spriteManager, imageManager, resourcePackManager);
        command.setExecutor(executor);
        command.setTabCompleter(executor);

        // Optional PlaceholderAPI
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            try {
                new zyr3xyt.yml.ssemojis.placeholder.ssEmojisExpansion(this, spriteManager).register();
                getLogger().info("PlaceholderAPI expansion registered.");
            } catch (Throwable t) {
                getLogger().warning("Could not register PlaceholderAPI expansion: " + t.getMessage());
            }
        }

        getLogger().info("ssEmojis enabled with " + spriteManager.getSprites().size() + " registered sprites.");
        if (resourcePackManager.isAutoHosting()) {
            getLogger().info("Auto resource-pack server running on port " + resourcePackManager.getHostPort());
        }
        getLogger().info("Developer: zyr3xyt.yml | Shark Studios");
    }

    @Override
    public void onDisable() {
        if (resourcePackManager != null) {
            resourcePackManager.shutdown();
        }
        getLogger().info("ssEmojis disabled.");
    }

    /** Full reload: config, sprites, images, resource pack. */
    public void fullReload() {
        reloadConfig();
        spriteManager.reload();

        FileConfiguration cfg = getConfig();
        imageManager.configure(
            cfg.getBoolean("images.enabled", true),
            cfg.getString("images.directory", "images"),
            cfg.getInt("images.max-width", 128),
            cfg.getInt("images.max-height", 128),
            cfg.getInt("images.max-file-size-kb", 256),
            cfg.getInt("images.glyph-start", 0xE100)
        );
        imageManager.reload();

        resourcePackManager.configure(
            cfg.getBoolean("resource-pack.auto-generate", true),
            cfg.getBoolean("resource-pack.auto-host", true),
            cfg.getInt("resource-pack.host-port", 8765),
            cfg.getString("resource-pack.host-bind", "0.0.0.0"),
            cfg.getString("resource-pack.public-host", null)
        );
        resourcePackManager.rebuildAndHost();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        if (!spriteManager.registry().colonParserEnabled()) {
            return;
        }
        Component original = event.message();
        String plain = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(original);
        if (!plain.contains(":")) {
            return;
        }
        Component parsed = spriteParser.parse(plain);
        event.message(parsed);
    }

    public ssEmoji getAPI() {
        return api;
    }

    public SpriteManager getSpriteManager() {
        return spriteManager;
    }

    public ImageManager getImageManager() {
        return imageManager;
    }

    public ResourcePackManager getResourcePackManager() {
        return resourcePackManager;
    }

    public MiniMessage getMiniMessage() {
        return miniMessage;
    }
}
